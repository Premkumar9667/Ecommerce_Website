from flask import Flask,render_template
app=Flask(__name__)
@app.route('/')
def home():
    return render_template('home.html')
@app.route('/profile')
def profile():
    return render_template('profile.html')
@app.route('/like')
def like():
    return render_template('like.html')
@app.route('/basket')
def basket():
    return render_template('basket.html')
@app.route('/contact')
def contact():
    return render_template('contact.html')
@app.route('/address')
def address():
    return render_template('address.html')
@app.route('/beds')
def beds():
    return render_template('beds.html')
@app.route('/dressingtables')
def dressingtables():
    return render_template('dressingtables.html')
@app.route('/centretables')
def centretables():
    return render_template('centretables.html')
@app.route('/dinningtables')
def dinningtables():
    return render_template('dinningtables.html')
@app.route('/officefurniture')
def officefurniture():
    return render_template('officefurniture.html')
@app.route('/recliners')
def recliners():
    return render_template('recliners.html')
@app.route('/shoeracks')
def shoeracks():
    return render_template('shoeracks.html')
@app.route('/sofas')
def sofas():
    return render_template('sofas.html')
@app.route('/studytables')
def studytables():
    return render_template('studytables.html')
@app.route('/newaccount')
def newaccount():
    return render_template('newaccount.html')
@app.route('/service')
def service():
    return render_template('service.html')


#beds 

@app.route('/beds1')
def beds1():
    return render_template('bed/beds1.html')
@app.route('/beds2')
def beds2():
    return render_template('bed/beds2.html')
@app.route('/beds3')
def beds3():
    return render_template('bed/beds3.html')
@app.route('/beds4')
def beds4():
    return render_template('bed/beds4.html')
@app.route('/beds5')
def beds5():
    return render_template('bed/beds5.html')
@app.route('/beds6')
def beds6():
    return render_template('bed/beds6.html')
@app.route('/beds7')
def beds7():
    return render_template('bed/beds7.html')
@app.route('/beds8')
def beds8():
    return render_template('bed/beds8.html')
@app.route('/beds9')
def beds9():
    return render_template('bed/beds9.html')
@app.route('/beds10')
def beds10():
    return render_template('bed/beds10.html')


#studytable

@app.route('/studytable1')
def studytables1():
    return render_template('studytable/studytable1.html')
@app.route('/studytable2')
def studytables2():
    return render_template('studytable/studytable2.html')
@app.route('/studytable3')
def studytables3():
    return render_template('studytable/studytable3.html')
@app.route('/studytable4')
def studytables4():
    return render_template('studytable/studytable4.html')
@app.route('/studytable5')
def studytables5():
    return render_template('studytable/studytable5.html')
@app.route('/studytable6')
def studytables6():
    return render_template('studytable/studytable6.html')
@app.route('/studytable7')
def studytables7():
    return render_template('studytable/studytable7.html')
@app.route('/studytable8')
def studytables8():
    return render_template('studytable/studytable8.html')
@app.route('/studytable9')
def studytables9():
    return render_template('studytable/studytable9.html')
@app.route('/studytable10')
def studytables10():
    return render_template('studytable/studytable10.html')
@app.route('/studytable11')
def studytables11():
    return render_template('studytable/studytable11.html')


#Dinningtable


@app.route('/dinningtables1')
def dinningtables1():
    return render_template('dinningtable/dinningtables1.html')
@app.route('/dinningtables2')
def dinningtables2():
    return render_template('dinningtable/dinningtables2.html')
@app.route('/dinningtables3')
def dinningtables3():
    return render_template('dinningtable/dinningtables3.html')
@app.route('/dinningtables4')
def dinningtables4():
    return render_template('dinningtable/dinningtables4.html')
@app.route('/dinningtables5')
def dinningtables5():
    return render_template('dinningtable/dinningtables5.html')
@app.route('/dinningtables6')
def dinningtables6():
    return render_template('dinningtable/dinningtables6.html')
@app.route('/dinningtables7')
def dinningtables7():
    return render_template('dinningtable/dinningtables7.html')
@app.route('/dinningtables8')
def dinningtables8():
    return render_template('dinningtable/dinningtables8.html')
@app.route('/dinningtables9')
def dinningtables9():
    return render_template('dinningtable/dinningtables9.html')
@app.route('/dinningtables10')
def dinningtables10():
    return render_template('dinningtable/dinningtables10.html')

#sofas

@app.route('/sofas1')
def sofas1():
    return render_template('sofas/sofas1.html')
@app.route('/sofas2')
def sofas2():
    return render_template('sofas/sofas2.html')
@app.route('/sofas3')
def sofas3():
    return render_template('sofas/sofas3.html')
@app.route('/sofas4')
def sofas4():
    return render_template('sofas/sofas4.html')
@app.route('/sofas5')
def sofas5():
    return render_template('sofas/sofas5.html')
@app.route('/sofas6')
def sofas6():
    return render_template('sofas/sofas6.html')
@app.route('/sofas7')
def sofas7():
    return render_template('sofas/sofas7.html')
@app.route('/sofas8')
def sofas8():
    return render_template('sofas/sofas8.html')
@app.route('/sofas9')
def sofas9():
    return render_template('sofas/sofas9.html')
@app.route('/sofas10')
def sofas10():
    return render_template('sofas/sofas10.html')

#centretables

@app.route('/centretables1')
def centretables1():
    return render_template('centretables/centretables1.html')
@app.route('/centretables2')
def centretables2():
    return render_template('centretables/centretables2.html')
@app.route('/centretables3')
def centretables3():
    return render_template('centretables/centretables3.html')
@app.route('/centretables4')
def centretables4():
    return render_template('centretables/centretables4.html')
@app.route('/centretables5')
def centretables5():
    return render_template('centretables/centretables5.html')
@app.route('/centretables6')
def centretables6():
    return render_template('centretables/centretables6.html')
@app.route('/centretables7')
def centretables7():
    return render_template('centretables/centretables7.html')
@app.route('/centretables8')
def centretables8():
    return render_template('centretables/centretables8.html')
@app.route('/centretables9')
def centretables9():
    return render_template('centretables/centretables9.html')
@app.route('/centretables10')
def centretables10():
    return render_template('centretables/centretables10.html')
@app.route('/centretables11')
def centretables11():
    return render_template('centretables/centretables11.html')

#recliners

@app.route('/recliners1')
def recliners1():
    return render_template('recliners/recliners1.html')
@app.route('/recliners2')
def recliners2():
    return render_template('recliners/recliners2.html')
@app.route('/recliners3')
def recliners3():
    return render_template('recliners/recliners3.html')
@app.route('/recliners4')
def recliners4():
    return render_template('recliners/recliners4.html')
@app.route('/recliners5')
def recliners5():
    return render_template('recliners/recliners5.html')
@app.route('/recliners6')
def recliners6():
    return render_template('recliners/recliners6.html')
@app.route('/recliners7')
def recliners7():
    return render_template('recliners/recliners7.html')
@app.route('/recliners8')
def recliners8():
    return render_template('recliners/recliners8.html')
@app.route('/recliners9')
def recliners9():
    return render_template('recliners/recliners9.html')

#officefurniture

@app.route('/officefurniture1')
def officefurniture1():
    return render_template('officefurniture/officefurniture1.html')
@app.route('/officefurniture2')
def officefurniture2():
    return render_template('officefurniture/officefurniture2.html')
@app.route('/officefurniture3')
def officefurniture3():
    return render_template('officefurniture/officefurniture3.html')
@app.route('/officefurniture4')
def officefurniture4():
    return render_template('officefurniture/officefurniture4.html')
@app.route('/officefurniture5')
def officefurniture5():
    return render_template('officefurniture/officefurniture5.html')
@app.route('/officefurniture6')
def officefurniture6():
    return render_template('officefurniture/officefurniture6.html')
@app.route('/officefurniture7')
def officefurniture7():
    return render_template('officefurniture/officefurniture7.html')
@app.route('/officefurniture8')
def officefurniture8():
    return render_template('officefurniture/officefurniture8.html')
@app.route('/officefurniture9')
def officefurniture9():
    return render_template('officefurniture/officefurniture9.html')
@app.route('/officefurniture10')
def officefurniture10():
    return render_template('officefurniture/officefurniture10.html')

#shoeracks

@app.route('/shoeracks1')
def shoeracks1():
    return render_template('shoeracks/shoeracks1.html')
@app.route('/shoeracks2')
def shoeracks2():
    return render_template('shoeracks/shoeracks2.html')
@app.route('/shoeracks3')
def shoeracks3():
    return render_template('shoeracks/shoeracks3.html')
@app.route('/shoeracks4')
def shoeracks4():
    return render_template('shoeracks/shoeracks4.html')
@app.route('/shoeracks5')
def shoeracks5():
    return render_template('shoeracks/shoeracks5.html')
@app.route('/shoeracks6')
def shoeracks6():
    return render_template('shoeracks/shoeracks6.html')
@app.route('/shoeracks7')
def shoeracks7():
    return render_template('shoeracks/shoeracks7.html')
@app.route('/shoeracks8')
def shoeracks8():
    return render_template('shoeracks/shoeracks8.html')
@app.route('/shoeracks9')
def shoeracks9():
    return render_template('shoeracks/shoeracks9.html')
@app.route('/shoeracks10')
def shoeracks10():
    return render_template('shoeracks/shoeracks10.html')
@app.route('/shoeracks11')
def shoeracks11():
    return render_template('shoeracks/shoeracks11.html')

#DRESSINGTABLES 

@app.route('/dressingtables1')
def dressingtables1():
    return render_template('dressingtables/dressingtables1.html')
@app.route('/dressingtables2')
def dressingtables2():
    return render_template('dressingtables/dressingtables2.html')
@app.route('/dressingtables3')
def dressingtables3():
    return render_template('dressingtables/dressingtables3.html')
@app.route('/dressingtables4')
def dressingtables4():
    return render_template('dressingtables/dressingtables4.html')
@app.route('/dressingtables5')
def dressingtables5():
    return render_template('dressingtables/dressingtables5.html')
@app.route('/dressingtables6')
def dressingtables6():
    return render_template('dressingtables/dressingtables6.html')


if __name__==("__main__"):
    app.run(debug=True)